#include "Daughter.h"

#include <iostream>

using namespace std;

Daughter::Daughter(int a)
{ 
 cout << "Daughter: int parameter\n\n"; 
}
