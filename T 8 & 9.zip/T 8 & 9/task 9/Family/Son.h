#pragma once

#include "Mother.h"

class Son : public Mother {
 public:
 Son(int a);
};