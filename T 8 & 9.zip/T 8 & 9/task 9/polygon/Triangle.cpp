#include "Triangle.h"

int Triangle::Area()
{
 return mWidth * mHeight / 2;
}