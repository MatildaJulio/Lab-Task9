#include "Rectangle.h"

int Rectangle:: Area()
{
 return mWidth * mHeight;
}