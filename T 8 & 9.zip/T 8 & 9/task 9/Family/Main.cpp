#include <iostream>
#include "Daughter.h"
#include "Son.h"

using namespace std;

int main () 
{
 
 Daughter theDaughter(1);
 Son theSon(2);
 
 return 0;
}
