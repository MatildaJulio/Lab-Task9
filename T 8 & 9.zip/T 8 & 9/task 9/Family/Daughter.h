#pragma once

#include "Mother.h"

class Daughter : public Mother {
 public:
 Daughter (int a);
};